# Creazione del Database
CREATE DATABASE ToysGroup;
USE ToysGroup;

# Creazione delle tabelle Product, Region, Sales

CREATE TABLE Product (
	id_product INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR (100) NOT NULL,
    cost DECIMAL (10,2) NOT NULL,
    category VARCHAR (100) NOT NULL,
    quantity INT
);

CREATE TABLE Region (
	id_region INT AUTO_INCREMENT PRIMARY KEY,
    region VARCHAR (100),
    country VARCHAR (100)
);

CREATE TABLE Sales (
	id_sale INT AUTO_INCREMENT PRIMARY KEY,
    order_date DATE DEFAULT (CURRENT_DATE),
    quantity INT,
    total_amount DECIMAL (10,2),
    id_product INT,
    id_region INT,
    FOREIGN KEY (id_product) REFERENCES Product(id_product),
    FOREIGN KEY (id_region) REFERENCES Region(id_region)
);

# Popolamento delle tabelle appena create

INSERT INTO Product (name, cost, category, quantity)
VALUES
('Teddy Bear', 15.00, 'Soft Toys', 120),
('Baby Doll', 18.00, 'Soft Toys', 140),
('Race Car', 25.00, 'Vehicles', 80),
('Fire Truck', 30.00, 'Vehicles', 60),
('Alphabet Puzzle', 20.00, 'Educational', 90),
('Building Blocks', 22.00, 'Educational', 100);

INSERT INTO Region (region, country)
VALUES
('WestEurope', 'France'),
('SouthEurope', 'Italy'),
('NorthAmerica', 'USA'),
('AsiaPacific', 'Japan');

INSERT INTO Sales (order_date, quantity, total_amount, id_product, id_region)
VALUES
('2025-01-10', 3, 45.00, 1, 1),
('2025-02-05', 2, 36.00, 2, 2),
('2025-02-12', 4, 100.00, 3, 3),
('2025-03-01', 1, 30.00, 4, 2),
('2025-03-15', 2, 40.00, 5, 4),
('2025-04-02', 5, 110.00, 6, 1);

SELECT * FROM Product;
SELECT * FROM Region;
SELECT * FROM Sales;

# 1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).
# Controlli per la tabella Product

SELECT DISTINCT id_product FROM Product; # Nessun duplicato nei risultati, questo conferma che id_product è una PK

SELECT 
	id_product, 
	COUNT(*) AS duplicati
FROM Product
GROUP BY id_product
HAVING COUNT(*) > 1; #non mi escono risultati, il che conferma che la PK di Product, non è duplicata. 

# Controlli per la tabella Region

SELECT DISTINCT id_region FROM Region; # Nessun duplicato nei risultati, questo conferma che id_product è una PK

SELECT 
	id_region, 
	COUNT(*) AS duplicati
FROM Region
GROUP BY id_region
HAVING COUNT(*) > 1; #non mi escono risultati, il che conferma che la PK di Product, non è duplicata. 

# Controlli per la tabella Sales

SELECT DISTINCT id_sale FROM Sales; # Nessun duplicato nei risultati, questo conferma che id_product è una PK

SELECT 
	id_sale, 
	COUNT(*) AS duplicati
FROM Sales
GROUP BY id_sale
HAVING COUNT(*) > 1; #non mi escono risultati, il che conferma che la PK di Product, non è duplicata. 

/* 2)	Esporre l’elenco delle transazioni indicando nel result set 
il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione 
che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT
	s.id_sale,
    s.order_date,
    p.name,
    p.category,
    r.country,
    r.region,
	CASE 
	  WHEN DATEDIFF(CURRENT_DATE, s.order_date) > 180 THEN 'True'
      ELSE 'False'
END AS maggiore_180_giorni
FROM Sales s
JOIN Product p ON s.id_product = p.id_product
JOIN Region r ON s.id_region = r.id_region;

/* 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
Nel result set devono comparire solo il codice prodotto e il totale venduto.*/

SELECT
	p.id_product,
    SUM(s.quantity) AS total_sold
FROM Product p
JOIN Sales s ON p.id_product = s.id_product
GROUP BY p.id_product
HAVING SUM(s.quantity) > (
SELECT AVG(quantity)
FROM Sales
WHERE YEAR(order_date) = (
  SELECT YEAR(order_date)
  FROM Sales
  ORDER BY order_date DESC
  LIMIT 1
));

/* 4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

SELECT
	p.id_product,
    p.name,
    SUM(s.total_amount) AS total_sales,
    YEAR(s.order_date) AS year_sold
FROM Product p 
JOIN Sales s ON p.id_product = s.id_product
GROUP BY p.id_product,
         p.name,
         YEAR(s.order_date);
         
/* 5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.*/

SELECT
	SUM(s.total_amount) AS total_sales,
	r.country,
	YEAR(s.order_date) AS year_sold
FROM Region r
JOIN Sales s ON r.id_region = s.id_region
GROUP BY
	r.country,
	YEAR(s.order_date)
ORDER BY
	year_sold,
	total_sales DESC;
    
/* 6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT
	p.category,
    SUM(s.total_amount) AS total_sold
FROM Sales s
JOIN Product p ON s.id_product = p.id_product
GROUP BY
	p.category
ORDER BY 
	total_sold DESC
LIMIT 1;

/* 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.*/
	# Modo 1: utilizza una LEFT JOIN per trovare i prodotti che non compaiono in alcuna vendita
SELECT 
    p.name
FROM Product p
LEFT JOIN Sales s ON p.id_product = s.id_product
WHERE s.id_product IS NULL;

	# Modo 2:  utilizza una subquery con NOT IN per individuare i prodotti mai venduti
SELECT 
    p.name
FROM Product p
WHERE p.id_product NOT IN (
    SELECT id_product 
    FROM Sales
);

/* 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW ProductsView AS 
SELECT 
	id_product,
    name,
    category
FROM Product;

/* 9)	Creare una vista per le informazioni geografiche */

CREATE VIEW GeographicalInfo AS
SELECT
	id_region,
    region,
    country
FROM Region;
